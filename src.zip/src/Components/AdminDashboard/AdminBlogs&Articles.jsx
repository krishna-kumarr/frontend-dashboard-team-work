import React from "react";
import "../Reusable-css/AdminSidebar.css"
import { DashboardHeader } from "../Reusable-jsx/DashboardHeader";
import { DashboardSidebar } from "../Reusable-jsx/DashboardSidebar";

export const AdminBlogsARticlesPage = () =>{

    return(
        <>
           
            <div class="height-100 main-content ps-4 py-2 header-default-background" >
                <h4>Blogs and articles Components</h4>
            </div>
      </>
    )
}