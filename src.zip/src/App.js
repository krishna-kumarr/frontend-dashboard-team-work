import React from "react";
import { ReactRouter } from "./Components/Router/Router";


function App() {  

  return (
      <div className="App" id="changeBackground">
          <ReactRouter/>
      </div>
  );
}

export default App;
